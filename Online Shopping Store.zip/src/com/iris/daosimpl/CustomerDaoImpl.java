package com.iris.daosimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iris.daos.CustomerDao;
import com.iris.models.Customer;
import com.iris.utility.ConnectionProvider;

public class CustomerDaoImpl implements CustomerDao{
	Connection conn=ConnectionProvider.getConnection();
	@Override
	public boolean registerCustomer(Customer cust) throws Exception {
	PreparedStatement pr=conn.prepareStatement("insert into customer values (id.nextval,?,?,?,?,?,'Customer')");
	pr.setString(1,cust.getName());
	pr.setString(2,cust.getPassword());
	pr.setString(3,cust.getGender());
	pr.setString(4,cust.getEmailId());
	pr.setString(5,cust.getCity());
	int i=pr.executeUpdate();
	if(i!=0) {
		return true;
	}
		return false;
	}

	@Override
	public Customer validate(String name, String password) throws Exception {
		PreparedStatement pr=conn.prepareStatement("select * from customer where name=? and password=?");
		pr.setString(1, name);
		pr.setString(2, password);
		ResultSet r=pr.executeQuery();
		if(r.next())
		{
			Customer c=new Customer();
			c.setId(r.getInt(1));
			c.setName(r.getString(2));
			c.setPassword(r.getString(3));
			c.setGender(r.getString(4));
			c.setEmailId(r.getString(5));
			c.setCity(r.getString(6));
			c.setRole(r.getString(7));
			return c;
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomer() throws Exception {
    List<Customer> cust=new ArrayList<>(); 
    PreparedStatement pr=conn.prepareStatement("select * from customer where role='Customer'");
 ResultSet r=pr.executeQuery();
 while(r.next())
	{
		Customer c=new Customer();
		c.setId(r.getInt(1));
		c.setName(r.getString(2));
		c.setPassword(r.getString(3));
		c.setGender(r.getString(4));
		c.setEmailId(r.getString(5));
		c.setCity(r.getString(6));
		c.setRole(r.getString(7));
		cust.add(c);
	}
		return cust;
	}

	@Override
	public boolean delete(int id) throws Exception {
		PreparedStatement pr=conn.prepareStatement("delete from customer where id=?");
		pr.setInt(1, id);
		int i=pr.executeUpdate();
		if(i!=0)
		{
			return true;
		}
		return false;
	}

	
	public Customer updateForm(int id) throws Exception {
		PreparedStatement pr=conn.prepareStatement("select * from customer where id=?");
		pr.setInt(1, id);
		ResultSet r=pr.executeQuery();
		if(r.next())
		{
			Customer c=new Customer();
			c.setId(r.getInt(1));
			c.setName(r.getString(2));
			c.setPassword(r.getString(3));
			c.setGender(r.getString(4));
			c.setEmailId(r.getString(5));
			c.setCity(r.getString(6));
			c.setRole(r.getString(7));
			return c;
		}
		return null;
	}

	@Override
	public boolean update(Customer cust) throws Exception {
		PreparedStatement ps=conn.prepareStatement("update customer set name=?,password=?,gender=?,emailId=?,city=?where Id=? ");
		ps.setString(1, cust.getName());
		ps.setString(2, cust.getPassword());
		ps.setString(3, cust.getGender());
		ps.setString(4, cust.getEmailId());
		ps.setString(5, cust.getCity());
		ps.setInt(6, cust.getId());
		int i=ps.executeUpdate();
		if(i!=0)
		{
			return true;
		}
		
		return false;
	
	}

}
