package com.iris.daos;

import java.util.List;

import com.iris.models.Customer;

public interface CustomerDao {
public boolean registerCustomer(Customer cust) throws Exception;
public Customer validate(String name,String password) throws Exception;
public List<Customer> getAllCustomer() throws Exception;
public boolean delete(int id) throws Exception;
public Customer updateForm(int id) throws Exception;


public boolean update(Customer cust) throws Exception;

}
