package com.iris.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daos.CustomerDao;
import com.iris.daosimpl.CustomerDaoImpl;
import com.iris.models.Customer;

/**
 * Servlet implementation class Updated
 */
@WebServlet("/Updated")
public class Updated extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updated() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	 CustomerDao daoObj=new CustomerDaoImpl();
	 String s1=request.getParameter("id");
	 int n=Integer.parseInt(s1);
	 String s2=request.getParameter("name");
	 String s3=request.getParameter("password");
	 String s4=request.getParameter("gender");
	 String s5=request.getParameter("emailId");
	 String s6=request.getParameter("city");
	

	 Customer c=new Customer(); 
	 c.setName(s2);
	 c.setPassword(s3);
	 c.setEmailId(s5);
	 c.setCity(s6);
	 c.setGender(s4);
	 c.setId(n);
	
	 boolean a=false;
	 try {
		a=daoObj.update(c);
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
		if(a==true)
	{
			out.println("Data Updated");
			RequestDispatcher rd=request.getRequestDispatcher("AllCustDetail");
			rd.include(request, response);
	}
	else
		{out.println("Data not Updated");}
	}
}


